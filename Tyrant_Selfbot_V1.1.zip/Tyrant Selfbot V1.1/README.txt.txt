fill out the config

**if program crashes on launch either you are banned from using Tyrant or your licence key is invalid**

discord.gg/f9ED5N42yx for help
